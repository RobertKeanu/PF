import Data.Char

voc :: Char -> Integer
voc a = if (elem a "aeiouAEIOU")
            then 1
        else 0

nrv :: [Char] -> Integer
nrv [] = 0
nrv (h:t) = voc h + nrv t

nrVocale :: [String] -> Integer
nrVocale [] = 0
nrVocale (x:xs) = if(x == reverse x)
                    then nrv x + nrVocale xs
                else nrVocale xs


f :: Integer-> [Integer] -> [Integer]
f q [] = []
f q (x:xs) = if (x `mod` 2 == 0)
                then x : (q : f q xs)
             else (x : f q xs)

semiPareComp :: [Int] -> [Int]
semiPareComp l = [x `div` 2 | x<-l , even x]

divizori :: Int -> [Int]
divizori q = [x | x <- [1..q], q`mod`x == 0]

listadiv :: [Int] -> [[Int]]
listadiv l = [divizori a | a <- l]

inIntervalRec :: Int->Int->[Int]->[Int]
inIntervalRec a b [] = []
inIntervalRec a b (x:xs) = if (x<= b && x>=a)
                                then x : inIntervalRec a b xs
                            else (inIntervalRec a b xs)
inIntervalComp :: Int->Int->[Int]->[Int]
inIntervalComp a b [] = []
inIntervalComp a b l = [x | x<-[a..b]]

pozitive :: [Int] -> Int
pozitive [] = 0
pozitive (x:xs) = if(x>0)
                    then 1 + pozitive xs
                else pozitive xs

pozitiveComp :: [Int] -> Int
pozitiveComp [] = 0
pozitiveComp l = sum[1 | x<-l ,x>0]

impareaux :: [Integer] -> Integer -> [Integer]
impareaux [] _ = []
impareaux (h:t) i = if(h`mod`2 /=0)
                        then i : impareaux t (i+1)
                    else impareaux t (i+1)

pozitiiImpareRec :: [Integer] -> [Integer]
pozitiiImpareRec l = impareaux l 0

pozitiiImpareComp :: [Integer] -> [Integer]
pozitiiImpareComp l = [index | (x,index)<-zip l[0..] , x `mod` 2 /=0]

multDigitsRec :: [Char] -> Int
multDigitsRec "" = 1
multDigitsRec (x:xs) = if(isDigit x)
                            then digitToInt(x) + multDigitsRec xs 
                       else multDigitsRec xs

multDigitsComp :: [Char] -> Int
multDigitsComp l = product[digitToInt(x) | x<-l, isDigit(x)]