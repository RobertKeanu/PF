poly :: Double->Double->Double->Double->Double
poly a b c x = a*(x^2)+b*x+c

eeny :: Integer->String
eeny a = if odd a 
            then "meeny"
        else "eeny"

fizzbuzz :: Integer->String
fizzbuzz a = if(mod a 3 == 0 && mod a 5 /= 0)
                then "Fizz"
            else if (mod a 3 /= 0 && mod a 5 == 0)
                then "Buzz"
            else "fizzbuzz"

tribonacci :: Integer->Integer
tribonacci a  
    |a<3 = a
    |a==3 = 2
    |otherwise = tribonacci(a-1) + tribonacci(a-2) +tribonacci(a-3)

tribonacciq :: Integer->Integer
tribonacciq 1 = 1
tribonacciq 2 = 1
tribonacciq 3 = 2 
tribonacciq n = tribonacciq(n-1) + tribonacciq(n-2) +tribonacciq(n-3)


binomial :: Integer->Integer->Integer
binomial a b
    |b == 0 = 1
    |a == 0 = 0
    |otherwise = binomial(a-1) b + binomial(a-1) (b-1)

verifL :: [Int]->Bool
verifL l = if(mod (length l) 2 == 1)
                    then False
            else True

takefinal :: [Int] -> Int -> [Int]
takefinal l s = drop(length l - s) l

remove :: [Int] -> Int -> [Int]
remove l s = take (s-1) l ++ drop(length l - s) l

semiPareRec :: [Int] -> [Int]
semiPareRec [] = []
semiPareRec (h:t)
    |even h = h `div` 2 : t'
    |otherwise = t'
    where t' = semiPareRec t

myreplicate :: Int -> Int -> [Int]
myreplicate 0 v = []
myreplicate n v = v : myreplicate(n-1) v

sumImp :: [Int] -> Int
sumImp [] = 0
sumImp (x:xs) = if odd x
                    then x + sumImp xs
                else sumImp xs

totalLen :: [String] -> Int
totalLen (h:t) = (if head h == 'A' then length h else 0) + totalLen t

