{-
class Functor f where
fmap : : ( a -> b ) -> f a -> f b
-}
newtype Identity a = Identity a
instance Functor Identity where
    fmap f(Identity a) = Identity (f a)


data Pair a = Pair a a
instance Functor Pair where
    fmap f (Pair a1 a2) = Pair (f a1) (f a2)

data Constant a b = Constant b
instance Functor (Constant a) where
    fmap f (Constant b1) = Constant (f b1)

data Two a b = Two a b
instance Functor (Two a) where
    fmap f(Two a b1) = Two a (f b1)


data Three a b c = Three a b c
instance Functor (Three a b) where
    fmap f(Three a b c1) = Three a b (f c1)


data Three' a b = Three' a b b
instance Functor (Three' a) where
    fmap f(Three' a b1 b2) = Three' a (f b1) (f b2)


data Four a b c d = Four a b c d
instance Functor (Four a b c) where
    fmap f(Four a b c d1) = Four a b c (f d1)



data Four'' a b = Four'' a a a b
instance Functor (Four'' a) where
    fmap f(Four'' a a1 a2 b1) = Four'' a a1 a2 (f b1)


data Quant a b = Finance | Desk a | Bloor b
instance Functor (Quant a) where
    fmap f(Finance) = Finance
    fmap f(Desk a) = Desk a
    fmap f(Bloor b1) = Bloor (f b1)

data LiftItOut f a = LiftItOut (f a)
instance Functor f => Functor (LiftItOut f) where
    fmap f (LiftItOut fa) = LiftItOut (fmap f  fa)

data Parappa f g a = DaWrappa (f a) (g a)
instance (Functor f,Functor g) => Functor (Parappa f g) where
    fmap f (DaWrappa g1 g2) = DaWrappa (fmap f g1) (fmap f g2)


data IgnoreOne f g a b = IgnoringSomething (f a) (g b)
instance (Functor g) => Functor (IgnoreOne f g a) where
    fmap f (IgnoringSomething g1 g2) = IgnoringSomething g1 (fmap f g2)


data Notorious g o a t = Notorious (g o) (g a) (g t)
instance (Functor g) => Functor (Notorious g o a) where
    fmap g (Notorious g1 g2 g3) = Notorious g1 g2 (fmap g g3)


data GoatLord a = NoGoat | OneGoat a | MoreGoats (GoatLord a) (GoatLord a) (GoatLord a)
instance Functor GoatLord where
    fmap f NoGoat = NoGoat
    fmap f (OneGoat a) = OneGoat (f a)
    fmap f (MoreGoats g1 g2 g3) = MoreGoats (fmap f g1) (fmap f g2) (fmap f g3)


data TalkToMe a = Halt | Print String a | Read (String -> a)
instance Functor TalkToMe where
    fmap f Halt = Halt
    fmap f (Print x a) = Print x (f a)
    fmap f (Read x) = Read (fmap f x)