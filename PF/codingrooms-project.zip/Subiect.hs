getFromInterval :: Int->Int->[Int]->[Int]
getFromInterval x n [] = []
getFromInterval x n (h:t) = if(h >= x && h <= n)
                                    then h : getFromInterval x n t
                                        else getFromInterval x n t

getFromInterval2 :: Int->Int->[Int]->[Int]
getFromInterval2 x n h = do
                            val <- h
                            if(val >=x && val <= n)
                                then return (val)
                            else []

{-newtype ReaderWriter env a = RW {getRW :: env -> (a,String)}

instance Monad (ReaderWriter env) where
  ma >>= k = RW f
    where
      f env =
        let (va, string1) = getRW ma env
            (vb, string2) = getRW (k va) env
         in (vb, string1 ++ string2)-}

data Point = Pt [Int]
            deriving Show

data Arb = Empty | Node Int Arb Arb
            deriving Show

class ToFromArb a where
    toArb :: a -> Arb
    fromArb :: Arb -> a 

fun :: Point -> [Int]
fun (Pt []) = []
fun (Pt (x:xs)) = x : fun(Pt xs)

instance ToFromArb Point where
    fromArb Empty = Pt []
    fromArb (Node a Empty Empty) = Pt [a]
    fromArb (Node a st dr) = Pt (fun(fromArb st) ++ [a] ++ fun(fromArb dr))
    
    toArb (Pt []) = Empty
    toArb (Pt [a]) = Node a Empty Empty
    toArb (Pt (x:xs))
        | length (x:xs) == 1 = Node x Empty Empty
        | otherwise =
             if x < ((x:xs) !! 1)
                then Node ((x:xs) !! 1) (Node x Empty Empty) (toArb (Pt (tail xs)))
                else Node x (Node ((x:xs) !! 1) Empty Empty) (toArb (Pt (tail xs)))




